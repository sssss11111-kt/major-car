Build logs are generated here. No private capture data is distributed.
