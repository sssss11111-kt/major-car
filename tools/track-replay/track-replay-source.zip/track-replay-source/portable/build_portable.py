"""Build a self-contained HTML with the identical C vision code as WebAssembly.
Build-only dependency: uv run --with ziglang==0.13.0 python build_portable.py
End users need only a modern browser, not Python, DLLs, or a server.
"""
import base64
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def main():
    import ziglang
    zig = Path(ziglang.__file__).parent/'zig.exe'
    manifest = json.loads((ROOT/'algorithm-manifest.json').read_text(encoding='utf-8'))
    for name, sha in manifest['sha256'].items():
        if name.endswith('.dll'):
            continue
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == sha, name
    exports = ['replay_reset', 'portable_input', 'portable_lines',
               'portable_thresholds', 'portable_metrics', 'portable_process']
    command = [str(zig), 'cc', '-target', 'wasm32-freestanding', '-O2', '-ffp-contract=off',
        '-fno-builtin', '-nostdlib', '-I', str(HERE/'wasm-include'),
        '-I', str(ROOT/'algorithm'), str(HERE/'wasm_adapter.c'),
        '-Wl,--no-entry', '-Wl,--export-memory',
        *['-Wl,--export='+e for e in exports],
        '-o', str(HERE/'replay_core.wasm')]
    result = subprocess.run(command, capture_output=True)
    (ROOT/'verification/wasm-build.log').write_text(
        result.stdout.decode('utf-8', errors='replace')+result.stderr.decode('utf-8', errors='replace'), encoding='utf-8')
    if result.returncode:
        raise RuntimeError((ROOT/'verification/wasm-build.log').read_text(encoding='utf-8'))
    wasm = (HERE/'replay_core.wasm').read_bytes()
    info = {'baseline': manifest['baseline'], 'source_sha256': manifest['sha256']['algorithm/img_process.c'],
            'wasm_sha256': hashlib.sha256(wasm).hexdigest(), 'adapter': 'portable/wasm_adapter.c',
            'firmware_modified': False, 'controller_replayed': False, 'guidance': 0}
    style = (ROOT/'web/style.css').read_text(encoding='utf-8')+'\n'+(HERE/'portable.css').read_text(encoding='utf-8')
    script = 'const ALGORITHM_B64='+json.dumps(base64.b64encode(wasm).decode())+';\nconst ALGORITHM_INFO='+json.dumps(info, ensure_ascii=False)+';\n'
    script += (HERE/'portable.js').read_text(encoding='utf-8')
    template = (HERE/'index.template.html').read_text(encoding='utf-8')
    output = template.replace('/* EMBED_STYLE */', style).replace('/* EMBED_SCRIPT */', script)
    (HERE/'赛道图像回放-便携版.html').write_text(output, encoding='utf-8')
    (HERE/'wasm-manifest.json').write_text(json.dumps(info, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'wasm_bytes': len(wasm), 'html_bytes': len(output.encode()), 'source_sha256': info['source_sha256']}))


if __name__ == '__main__':
    main()
