#ifndef PORTABLE_STRING_H
#define PORTABLE_STRING_H
typedef __SIZE_TYPE__ size_t;
void *memcpy(void *dest, const void *source, size_t count);
void *memset(void *dest, int value, size_t count);
#endif
