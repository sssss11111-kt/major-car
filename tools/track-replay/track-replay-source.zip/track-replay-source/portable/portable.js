'use strict';
const $ = id => document.getElementById(id);
const W = 188, H = 120, SIZE = W*H;
const NAMES = ['valid','error','usable_rows','both_rows','preview_error','preview_valid','near_valid','near_rows','stripe','stripe_rows','island_candidate','island_evidence','entry_error'];
const utf8 = new TextEncoder(), text = new TextDecoder();
let engine, frames = [], index = 0, busy = false, playing = false, timer;
let recordName = '', analysisMode = 'continuous', frozen = false, warnings = [], errors = [];
function b64(bytes) { let s=''; for(let i=0;i<bytes.length;i+=16384) s+=String.fromCharCode(...bytes.subarray(i,i+16384)); return btoa(s); }
function un64(s) { return Uint8Array.from(atob(s), c=>c.charCodeAt(0)); }
async function sha(bytes) { return [...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(v=>v.toString(16).padStart(2,'0')).join(''); }
function crc32(bytes) { let crc=0xffffffff; for(const b of bytes){crc^=b;for(let k=0;k<8;k++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}return ((crc^0xffffffff)>>>0).toString(16).padStart(8,'0'); }
function notice(s, cls='') { $('notice').textContent=s; $('notice').className=cls; }
function pause() { playing=false; clearTimeout(timer); $('play').textContent='播放'; }
function failure(error) { pause(); notice(error.message || String(error),'error'); }
function enabled() {
  const ok=frames.length>0&&!busy;
  for(const id of ['prev','play','next','jump','jumpGo','timeline','note','mark','unmark','exportHtml','exportData','from','to','reanalyze']) $(id).disabled=!ok;
  for(const id of ['folderButton','filesButton','mode']) $(id).disabled=busy;
}
function setBusy(value) { busy=value; enabled(); }
function tick() { return new Promise(resolve=>setTimeout(resolve,0)); }
function normalPath(value) { return String(value).replaceAll('\\','/').replace(/^\.\//,''); }

function parsePGM(data) {
  let p=0;const tokens=[];
  const whitespace=v=>[9,10,13,32].includes(v);
  while(tokens.length<4) {
    while(p<data.length&&whitespace(data[p]))p++;
    if(data[p]===35){while(p<data.length&&data[p]!==10)p++;continue;}
    const start=p;while(p<data.length&&!whitespace(data[p])&&data[p]!==35)p++;
    if(start===p)throw Error('PGM 文件头不完整');
    tokens.push(text.decode(data.subarray(start,p)));
  }
  if(tokens.join(',')!=='P5,188,120,255')throw Error('需要188×120、8位 P5 PGM原图，不能使用缩略图');
  if(!whitespace(data[p]))throw Error('PGM 缺少图像分隔符');
  p+=(data[p]===13&&data[p+1]===10)?2:1;
  if(data.length-p!==SIZE)throw Error('原图像素长度不完整');
  return data.slice(p);
}
async function validatePixels(frame) {
  if(!(frame.pixels instanceof Uint8Array)||frame.pixels.length!==SIZE)throw Error('原图长度错误');
  frame.sha256=await sha(frame.pixels);
  const expected=frame.recorded.sha256;
  if(expected&&frame.sha256!==String(expected).toLowerCase())throw Error('SHA256 与原记录不符');
  if(frame.recorded.crc32&&crc32(frame.pixels)!==String(frame.recorded.crc32).toLowerCase())throw Error('CRC32 与原记录不符');
  frame.integrity=expected||frame.recorded.crc32?'verified':'length-only';
}
function calc(frame) {
  new Uint8Array(engine.memory.buffer,engine.portable_input(),SIZE).set(frame.pixels);
  engine.portable_process();
  const values=new Int32Array(engine.memory.buffer,engine.portable_metrics(),13);
  return {metrics:Object.fromEntries(NAMES.map((key,n)=>[key,values[n]])),
    lines:b64(new Uint8Array(engine.memory.buffer,engine.portable_lines(),360)),
    thresholds:b64(new Uint8Array(engine.memory.buffer,engine.portable_thresholds(),120)),
    sha256:frame.sha256,integrity:frame.integrity};
}
function checkResult(result) {
  return result&&typeof result.lines==='string'&&typeof result.thresholds==='string'&&
    un64(result.lines).length===360&&un64(result.thresholds).length===120&&
    result.metrics&&NAMES.every(key=>Number.isInteger(result.metrics[key]));
}
async function analyze() {
  if(!frames.length)return;
  pause();setBusy(true);frozen=false;analysisMode=$('mode').value;
  try {
    engine.replay_reset();let previous=null;
    for(let n=0;n<frames.length;n++) {
      const frame=frames[n],board=frame.recorded.board_frame;
      const delta=Number.isInteger(board)&&Number.isInteger(previous)?(board-previous)>>>0:null;
      const reset=analysisMode==='independent'||n===0||frame.breakBefore||delta===0||delta>=0x80000000;
      if(reset)engine.replay_reset();
      frame.result={...calc(frame),board_delta:delta,reset};
      previous=board;
      if(n%16===0){notice(`正在使用内置 C 视觉算法分析 ${n+1} / ${frames.length} 张…`,'loading');await tick();}
    }
    ready();
  }finally{setBusy(false);}
}
function ready() {
  $('sourceName').textContent=`${recordName} · ${frames.length} 张 · ${analysisMode==='independent'?'每帧重置历史':'按保存顺序保留视觉历史'}`;
  $('timeline').max=frames.length-1;$('jump').max=frames.length;
  $('from').max=$('to').max=frames.length;$('from').value=1;$('to').value=Math.min(300,frames.length);
  $('resultKind').textContent=frozen?'文件内保存的离线结果':'浏览器重算';
  renderMarks();show(0);enabled();
}
async function loadFiles(fileList) {
  await initialized;
  const files=[...fileList];if(!files.length)return;
  pause();setBusy(true);frames=[];errors=[];warnings=[];
  $('counter').textContent='0 / 0';
  for(const id of ['raw','binary','overlay'])$(id).parentElement.classList.remove('loaded');
  try {
    const portable=files.find(file=>/\.trackreplay$/i.test(file.name));
    if(portable){await loadPacked(new Uint8Array(await portable.arrayBuffer()),portable.name);return;}
    const pgms=files.filter(file=>/\.pgm$/i.test(file.name));
    if(!pgms.length)throw Error('未找到 PGM 原图或 .trackreplay 数据，请选择原采集文件夹');
    const metas=files.filter(file=>file.name==='frames.jsonl');
    if(metas.length>1)throw Error('一次请选择一组采集记录，不要选择包含多个采集子目录的总文件夹');
    const paths=new Map(),basenames=new Map();
    for(const file of pgms){paths.set(normalPath(file.webkitRelativePath||file.name),file);const list=basenames.get(file.name)||[];list.push(file);basenames.set(file.name,list);}
    let rows;
    if(metas.length) {
      rows=[];const lines=(await metas[0].text()).replace(/^\uFEFF/,'').split(/\r?\n/);
      for(let n=0;n<lines.length;n++)if(lines[n].trim()) {
        try{const row=JSON.parse(lines[n]);if(!row||typeof row!=='object'||typeof row.file!=='string')throw Error('缺少图像路径');rows.push(row);}
        catch(error){errors.push({file:`元数据第${n+1}行`,reason:error.message});}
      }
    } else {rows=[...pgms].sort((a,b)=>a.name.localeCompare(b.name,undefined,{numeric:true})).map(file=>({file:normalPath(file.webkitRelativePath||file.name)}));warnings.push('未导入 frames.jsonl；无法核对车端帧号、原始时间和校验值。');}
    const prefix=metas.length?normalPath(metas[0].webkitRelativePath||metas[0].name).replace(/[^/]*$/,''):'';
    recordName=prefix.replace(/\/$/,'').split('/').pop()||'导入的原图';let broken=false;
    for(let n=0;n<rows.length;n++) {
      const row=rows[n],name=normalPath(row.file);
      try {
        let file=paths.get(prefix+name)||paths.get(name);
        if(!file){const candidates=basenames.get(name.split('/').pop())||[];if(candidates.length!==1)throw Error('没有找到唯一对应的 PGM 原图');file=candidates[0];}
        const frame={pixels:parsePGM(new Uint8Array(await file.arrayBuffer())),filename:name,recorded:row,note:'',breakBefore:broken};
        await validatePixels(frame);frames.push(frame);broken=false;
      }catch(error){errors.push({file:name,reason:error.message});broken=true;}
      if(n%20===0){notice(`正在读取与校验原图 ${n+1} / ${rows.length} 张…`,'loading');await tick();}
    }
    if(!frames.length)throw Error('没有通过校验的188×120原图：'+JSON.stringify(errors.slice(0,2)));
    await analyze();
  }finally{setBusy(false);}
}

async function loadPacked(bytes,name='便携记录') {
  if(bytes[0]===31&&bytes[1]===139) {
    if(!globalThis.DecompressionStream)throw Error('当前浏览器不支持解压便携记录，请使用新版 Chrome / Edge / Firefox / Safari');
    bytes=new Uint8Array(await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer());
  }
  if(text.decode(bytes.subarray(0,4))!=='TRP1')throw Error('不是有效的赛道便携记录');
  const headerSize=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength).getUint32(4,true);
  if(headerSize>bytes.length-8)throw Error('便携记录文件头不完整');
  const header=JSON.parse(text.decode(bytes.subarray(8,8+headerSize)));
  if(header.format!=='track-replay-v1'||header.width!==W||header.height!==H||!Array.isArray(header.frames)||!header.frames.length||bytes.length!==8+headerSize+header.frames.length*SIZE)throw Error('便携记录尺寸或长度错误');
  frames=[];warnings=Array.isArray(header.warnings)?header.warnings.map(String):[];errors=[];recordName=String(header.name||name);
  analysisMode=header.mode==='independent'?'independent':'continuous';$('mode').value=analysisMode;
  let saved=header.algorithm?.source_sha256===ALGORITHM_INFO.source_sha256&&header.frames.every(item=>checkResult(item.result));
  let broken=false;
  for(let n=0;n<header.frames.length;n++) {
    const item=header.frames[n],start=8+headerSize+n*SIZE;
    try {
      const frame={pixels:bytes.slice(start,start+SIZE),filename:String(item.filename||`${n}.pgm`),recorded:item.recorded||{},note:String(item.note||''),result:item.result,breakBefore:!!item.breakBefore||broken};
      await validatePixels(frame);
      if(item.sha256&&frame.sha256!==item.sha256)throw Error('便携记录像素校验失败');
      if(saved&&item.result.sha256!==frame.sha256)throw Error('分析结果与原图校验值不匹配');
      frames.push(frame);broken=false;
    }catch(error){errors.push({file:item.filename,reason:error.message});broken=true;saved=false;}
    if(n%20===0){notice(`正在校验便携数据 ${n+1} / ${header.frames.length} 张…`,'loading');await tick();}
  }
  if(!frames.length)throw Error('便携记录没有通过校验的原图');
  if(saved){frozen=true;ready();}else{warnings.push('文件未包含匹配当前算法的完整结果，已用内置算法重新分析。');await analyze();}
}

function drawCanvas(id,pixels,channels=1) {
  const context=$(id).getContext('2d'),data=context.createImageData(W,H);
  for(let n=0;n<SIZE;n++){data.data[n*4]=pixels[n*channels];data.data[n*4+1]=pixels[n*channels+(channels===3?1:0)];data.data[n*4+2]=pixels[n*channels+(channels===3?2:0)];data.data[n*4+3]=255;}
  context.putImageData(data,0,0);$(id).parentElement.classList.add('loaded');
}
function renderImages(frame) {
  const thresholds=un64(frame.result.thresholds),lines=un64(frame.result.lines);
  const binary=new Uint8Array(SIZE),overlay=new Uint8Array(SIZE*3);
  for(let n=0;n<SIZE;n++){binary[n]=frame.pixels[n]>thresholds[Math.floor(n/W)]?255:0;overlay.set([frame.pixels[n],frame.pixels[n],frame.pixels[n]],n*3);}
  const colors=[[0,151,230],[245,163,26],[213,60,131]];
  for(let y=18;y<=105;y++)if(lines[120+y])for(let channel=0;channel<3;channel++){const x=lines[channel*120+y];if(x>0&&x<187)overlay.set(colors[channel],(y*W+x)*3);}
  drawCanvas('raw',frame.pixels);drawCanvas('binary',binary);drawCanvas('overlay',overlay,3);
}
function show(target) {
  if(!frames.length)return;index=Math.max(0,Math.min(frames.length-1,Math.floor(target)||0));
  const frame=frames[index],m=frame.result.metrics,r=frame.recorded;renderImages(frame);
  $('counter').textContent=`${index+1} / ${frames.length}`;$('timeline').value=index;$('jump').value=index+1;
  $('frameId').textContent='车端帧号 '+(r.board_frame??'未记录');$('hostTime').textContent='采集时间 '+(r.host_time?.replace('T',' ')||'未记录');
  $('gap').textContent='车端帧号间隔 '+(frame.result.board_delta??'首张')+(frame.result.reset?' / 历史已重置':'');
  $('integrity').textContent=frame.integrity==='verified'?'原记录像素校验通过':'已计算原图 SHA256 / 无原记录对照';
  const items=[['巡线有效',m.valid?'有效':'无效',m.valid?'good':'bad'],['横向偏差',m.error+' px',''],['有效行数',m.usable_rows,''],['近场可信',m.near_valid?'是':'否',''],['条纹识别',m.stripe?'检出':'未检出',''],['环岛候选',m.island_candidate?'检出':'未检出','']];
  $('metrics').replaceChildren();for(const [label,value,cls]of items){const div=document.createElement('div'),dt=document.createElement('dt'),dd=document.createElement('dd');dt.textContent=label;dd.textContent=value;dd.className=cls;div.append(dt,dd);$('metrics').append(div);}
  const thresholds=[...un64(frame.result.thresholds)];$('thresholds').textContent='8 个行带阈值：'+thresholds.filter((v,n)=>n%15===0).join(' / ');
  $('recorded').textContent=JSON.stringify(r.state||{说明:'原记录没有车辆状态'},null,2);
  $('diagnostic').textContent=JSON.stringify({算法:ALGORITHM_INFO,指标:m,来源:frozen?'文件保存的离线结果':'浏览器本地重算',分行阈值:thresholds,警告:warnings,排除文件:errors},null,2);
  $('note').value=frame.note;$('mark').textContent=frame.note?'保存标记说明':'标记当前帧';
  let gaps=0,missing=0;for(const f of frames){const d=f.result.board_delta;if(d>1&&d<0x80000000){gaps++;missing+=d-1;}}
  notice(`${recordName}　${frames.length} 张。${frozen?'保留文件中的离线结果。':''}${gaps?`帧号有 ${gaps} 处间隔、缺少 ${missing} 个帧号；未补造图像。`:''}${errors.length?`已排除 ${errors.length} 个错误文件。`:''}`);
}
function renderMarks(){const marked=frames.map((f,n)=>f.note?n:null).filter(n=>n!==null);$('markCount').textContent=`已标记 ${marked.length} 张`;$('marks').replaceChildren();for(const n of marked){const b=document.createElement('button');b.textContent=`第 ${n+1} 张`;b.title=frames[n].note;b.addEventListener('click',()=>{pause();show(n);});$('marks').append(b);}}
function mark(){if(!frames.length)return;pause();frames[index].note=$('note').value||'待检查';renderMarks();$('mark').textContent='保存标记说明';notice('标记已保留在当前页面；点击保存问题对照 HTML 或便携数据，将标记一起带走。');}
function interval(){const a=frames[index]?.recorded,b=frames[index+1]?.recorded;let ms=170;if(a&&b){if(Number.isFinite(a.host_monotonic)&&Number.isFinite(b.host_monotonic))ms=(b.host_monotonic-a.host_monotonic)*1000;else if(a.host_time&&b.host_time)ms=Date.parse(b.host_time)-Date.parse(a.host_time);}return Math.max(20,(ms>0?ms:170)/+$('speed').value);}
function play(){if(playing)return pause();if(!frames.length)return;if(index===frames.length-1)show(0);playing=true;$('play').textContent='暂停';const step=()=>{if(!playing)return;if(index>=frames.length-1)return pause();show(index+1);timer=setTimeout(step,interval());};timer=setTimeout(step,interval());}
function download(blob,name){globalThis.PortableReplay.lastExport={blob,name};const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);}
async function pack(indexes){
  const header={format:'track-replay-v1',width:W,height:H,name:recordName,mode:analysisMode,algorithm:ALGORITHM_INFO,warnings,
    subset:indexes.length!==frames.length,frames:indexes.map(n=>{const f=frames[n];return {filename:f.filename,recorded:f.recorded,note:f.note,result:f.result,sha256:f.sha256,breakBefore:f.breakBefore};})};
  if(header.subset)header.warnings=[...warnings,'本文件为选中的问题帧，保存原分析结果；重新分析子集不能重建已缺失的历史状态。'];
  const json=utf8.encode(JSON.stringify(header)),raw=new Uint8Array(8+json.length+indexes.length*SIZE);raw.set(utf8.encode('TRP1'));new DataView(raw.buffer).setUint32(4,json.length,true);raw.set(json,8);
  indexes.forEach((n,i)=>raw.set(frames[n].pixels,8+json.length+i*SIZE));
  if(globalThis.CompressionStream)return new Uint8Array(await new Response(new Blob([raw]).stream().pipeThrough(new CompressionStream('gzip'))).arrayBuffer());
  return raw;
}
async function exportHTML(){if(!frames.length)return;pause();setBusy(true);try{let selected=frames.map((f,n)=>f.note?n:null).filter(n=>n!==null);if(!selected.length)selected=[index];notice('正在把问题帧、算法和已保存结果打包成一个 HTML…','loading');const data=await pack(selected);const clone=document.documentElement.cloneNode(true);clone.querySelector('#embeddedRecord').textContent=b64(data);download(new Blob(['<!doctype html>\n',clone.outerHTML],{type:'text/html;charset=utf-8'}),'赛道问题对照-'+new Date().toISOString().slice(0,10)+'.html');$('exportStatus').textContent=`已生成 ${selected.length} 张问题帧的独立 HTML，请在浏览器下载位置查看。它包含原图、标记和原离线结果，可直接复制给其他设备。`;}finally{setBusy(false);}}
async function exportData(){if(!frames.length)return;pause();setBusy(true);try{const from=Math.max(1,Math.floor(+$('from').value)||1),to=Math.min(frames.length,Math.floor(+$('to').value)||frames.length);if(to<from)throw Error('导出结束张数不能小于起始张数');notice('正在无损打包选定范围…','loading');const selected=Array.from({length:to-from+1},(_,n)=>n+from-1);download(new Blob([await pack(selected)],{type:'application/octet-stream'}),`赛道记录-${from}-${to}.trackreplay`);$('exportStatus').textContent=`已生成第 ${from}–${to} 张的便携数据，请在浏览器下载位置查看。复制此数据和便携版 HTML 到其他设备即可重新打开。`;}finally{setBusy(false);}}
const action=(id,handler)=>$(id).addEventListener('click',()=>Promise.resolve().then(handler).catch(failure));
action('folderButton',()=>$('folderInput').click());action('filesButton',()=>$('filesInput').click());
for(const id of ['folderInput','filesInput'])$(id).addEventListener('change',()=>loadFiles($(id).files).catch(failure).finally(()=>{$(id).value='';}));
action('reanalyze',analyze);action('prev',()=>{pause();show(index-1);});action('next',()=>{pause();show(index+1);});action('play',play);action('jumpGo',()=>{pause();show(+$('jump').value-1);});$('timeline').addEventListener('input',()=>{pause();show(+$('timeline').value);});
action('mark',mark);action('unmark',()=>{frames[index].note='';$('note').value='';renderMarks();$('mark').textContent='标记当前帧';});$('note').addEventListener('focus',pause);action('exportHtml',exportHTML);action('exportData',exportData);
document.addEventListener('keydown',event=>{if(['INPUT','TEXTAREA','SELECT','BUTTON','SUMMARY'].includes(event.target.tagName)||!frames.length||busy)return;if(event.key===' '){event.preventDefault();play();}if(event.key==='ArrowLeft'||event.key==='ArrowRight'){event.preventDefault();pause();show(index+(event.key==='ArrowRight'?1:-1));}if(event.key.toLowerCase()==='m')mark();});
const initialized=(async()=>{if(!globalThis.WebAssembly||!crypto?.subtle)throw Error('请用新版 Chrome / Edge / Firefox / Safari 打开 HTML 文件');const wasm=un64(ALGORITHM_B64);if(await sha(wasm)!==ALGORITHM_INFO.wasm_sha256)throw Error('内置算法校验失败');engine=(await WebAssembly.instantiate(wasm,{})).instance.exports;notice('请选择原采集文件夹，或导入 .trackreplay 便携记录。无需联网或安装程序。');})();
globalThis.PortableReplay={ready:initialized,loadFiles,loadPacked:async(bytes,name)=>{await initialized;setBusy(true);try{await loadPacked(bytes,name);}finally{setBusy(false);}},analyze,show,
  frames:()=>frames,info:ALGORITHM_INFO,pack,parsePGM};
initialized.then(async()=>{const embedded=$('embeddedRecord').textContent.trim();if(embedded){setBusy(true);try{await loadPacked(un64(embedded),'问题帧对照');}finally{setBusy(false);}}}).catch(failure);
