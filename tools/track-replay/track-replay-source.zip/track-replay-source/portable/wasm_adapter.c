/* Browser-only adapter. No firmware or vision-algorithm changes. */
#include "../replay_core.c"

void *memcpy(void *dest, const void *source, size_t count) {
    unsigned char *d = (unsigned char *)dest;
    const unsigned char *s = (const unsigned char *)source;
    for (size_t i=0; i<count; ++i) d[i]=s[i];
    return dest;
}
void *memset(void *dest, int value, size_t count) {
    unsigned char *d = (unsigned char *)dest;
    for (size_t i=0; i<count; ++i) d[i]=(unsigned char)value;
    return dest;
}

static uint8_t input_pixels[188*120];
static uint8_t output_lines[360], output_thresholds[120];
static int32_t output_metrics[13];

uint32_t portable_input(void) { return (uint32_t)(uintptr_t)input_pixels; }
uint32_t portable_lines(void) { return (uint32_t)(uintptr_t)output_lines; }
uint32_t portable_thresholds(void) { return (uint32_t)(uintptr_t)output_thresholds; }
uint32_t portable_metrics(void) { return (uint32_t)(uintptr_t)output_metrics; }
void portable_process(void) {
    replay_process(input_pixels, output_lines, output_thresholds, output_metrics);
}
