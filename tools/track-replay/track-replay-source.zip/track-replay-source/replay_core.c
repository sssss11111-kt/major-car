/* Desktop-only adapter. The pinned firmware implementation is included without
 * edits so its actual row thresholds can be exported after auxiliary_process. */
#include "algorithm/img_process.c"
#ifdef _WIN32
#define API __declspec(dllexport)
#else
#define API
#endif

API void replay_reset(void) { img_process_reset(); }

API void replay_process(uint8_t *raw, uint8_t *lines, uint8_t *thresholds,
                        int32_t *metrics)
{
    img_set_roundabout_guidance(0);
    auxiliary_process(raw, IP_H, IP_W, 127, lines, lines+IP_H, lines+2*IP_H);
    memcpy(thresholds, s_row_thr, IP_H);
    metrics[0] = img_get_valid();
    metrics[1] = img_get_error();
    metrics[2] = img_get_usable_rows();
    metrics[3] = img_get_both_rows();
    metrics[4] = img_get_preview_error();
    metrics[5] = img_get_preview_valid();
    metrics[6] = img_get_near_valid();
    metrics[7] = img_diag_near_rows();
    metrics[8] = img_get_stripe_active();
    metrics[9] = img_get_stripe_rows();
    metrics[10] = img_get_roundabout_candidate();
    metrics[11] = img_get_roundabout_evidence();
    metrics[12] = img_get_roundabout_entry_error();
}
